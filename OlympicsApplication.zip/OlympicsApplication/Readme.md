This is an Olympics Application created. It consists of entities - Teams, Players, Medals, Coaches.
These entities are used to represent the real-world objects for the same -Teams, Players, Medals, Coaches.
The localhost URL used for it is - http://localhost:5141 .


Also, this is the link for the url of Swagger operating for backend - http://localhost:5141/swagger/index.html . You may visit the link to check for the APIs that have been created.


The URLs generated from the backend through Swagger have been implemented for the Frontend(using Angular) as follows :


- For File upload for different entities  - http://localhost:4200/TeamsFileUpload
- For Fetching data for the entities      - http://localhost:4200/FetchTeamsData
- For creating Charts required            - http://localhost:4200/TopNationsChart


In this project, the folder structure is defined as follows :
Core - It consists of Models and BLL, where Models -- Entity, Entity Mapper, DTO and BLL consists of the Functionalities(Services)
Infrastructure - It consists of Database and Migrations
Controllers - It consists of Data Controller and Excel Controller 
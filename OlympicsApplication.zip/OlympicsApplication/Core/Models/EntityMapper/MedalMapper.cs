using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using OlympicsApplication.Models.Entity;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace OlympicsApplication.Models.EntityMapper
{
    public class MedalMapper
    {
        public MedalMapper(EntityTypeBuilder<Medals> entityTypeBuilder)
        {
            entityTypeBuilder.HasKey(p => p.TeamId);
            entityTypeBuilder.Property(p => p.Rank).IsRequired();
            entityTypeBuilder.Property(p => p.Type).IsRequired();

        }
    }
}
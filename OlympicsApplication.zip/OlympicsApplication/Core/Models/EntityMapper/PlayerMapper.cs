using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using OlympicsApplication.Models.Entity;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace OlympicsApplication.Models.EntityMapper
{
    public class PlayerMapper
    {
        public PlayerMapper(EntityTypeBuilder<Players> entityTypeBuilder)
        {
            entityTypeBuilder.HasKey(p => p.PlayerId);
            entityTypeBuilder.Property(p => p.PlayerName).IsRequired();
            entityTypeBuilder.Property(p => p.Age).IsRequired();        

            entityTypeBuilder.HasOne(p=>p.team).WithMany(t=>t.players).HasForeignKey(p=>p.TeamId);

        }
    }
}
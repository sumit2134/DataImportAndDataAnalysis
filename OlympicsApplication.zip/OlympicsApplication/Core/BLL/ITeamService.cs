using System;
using OlympicsApplication.OlympicsDTO;
using OlympicsApplication.Models.Entity;

namespace OlympicsApplication.Functionality
{
    public interface ITeamService
    {
          public int AddTeam(TeamViewModel teamViewModel);
          List<Team> GetTeams();  
          void SaveTeams(List<Team> teams)  ;
    }
}
using System;
using OlympicsApplication.OlympicsDTO;
using OlympicsApplication.Database;
using Microsoft.EntityFrameworkCore;
using OlympicsApplication.Models.Entity;


namespace OlympicsApplication.Functionality
{
    public class PlayerService : IPlayerService
    {
        private readonly OlympicsDbContext olympicsDbContext;

        public PlayerService(OlympicsDbContext _olympicsDbContext)
        {
            olympicsDbContext = _olympicsDbContext;
        }

        int? IPlayerService.AddPlayer(PlayerViewModel playerViewModel)
        {
            Players objplayer = new Players();
            int id = 0;
            id = objplayer.TeamId;
            objplayer.TeamId = playerViewModel.TeamId;
            objplayer.PlayerName = playerViewModel.PlayerName;
            objplayer.Country = playerViewModel.Country;
            objplayer.Age = playerViewModel.Age;
            objplayer.TeamName = playerViewModel.TeamName;
            objplayer.Gender = playerViewModel.Gender;


            olympicsDbContext.Players.Add(objplayer);
            return olympicsDbContext.SaveChanges();
        }


        int IPlayerService.DeletePlayer(int id)
        {
            var player = olympicsDbContext.Players.SingleOrDefault(t => t.PlayerId == id);
            if (player != null)
            {
                olympicsDbContext.Remove(player);
                return olympicsDbContext.SaveChanges();
            }
            return -1;       // if no player to delete --> return -1 
        }

        object IPlayerService.FetchPlayerbyid(int id)
        {
            var player = (from a in olympicsDbContext.Players
                          join b in olympicsDbContext.Teams on a.TeamId equals b.TeamId
                          join add in olympicsDbContext.Coaches on b.TeamId equals add.TeamId

                          where a.PlayerId == id
                          select new
                          {
                              a.PlayerName,
                              a.Country,
                              a.Age,
                              a.Gender,
                              teamName = b.TeamName,
                              teamCountry = b.Country,
                              coachName = add.CoachName,
                              coachAge = add.CoachAge,

                          }).FirstOrDefault();

            return player;
        }

        List<Players> IPlayerService.GetPlayers()
        {
            var result = olympicsDbContext.Players.Include(t => t.team).ToList();
            return result;
        }

        void IPlayerService.SavePlayers(List<Players> players)
        {
            olympicsDbContext.Players.AddRange(players);
            olympicsDbContext.SaveChanges();
        }

        int IPlayerService.UpdatePlayer(PlayerViewModel playerViewModel)
        {

            Players objplayer = new Players();
            int id = 0;
            id = objplayer.TeamId;
            objplayer.TeamId = playerViewModel.TeamId;
            objplayer.PlayerName = playerViewModel.PlayerName;
            objplayer.Country = playerViewModel.Country;
            objplayer.Age = playerViewModel.Age;
            objplayer.TeamName = playerViewModel.TeamName;
            objplayer.Gender = playerViewModel.Gender;


            olympicsDbContext.Players.Add(objplayer);
            return olympicsDbContext.SaveChanges();
        }

    }

}

using OlympicsApplication.Models.Entity;
using OlympicsApplication.Database;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;

namespace OlympicsApplication.Functionality
{
    public class PlayerReader : IExcelPlayerReader
    {

        private readonly OlympicsDbContext _context;

        public PlayerReader(OlympicsDbContext context)
        {
            _context = context;
        }

        IEnumerable<string> IExcelPlayerReader.ReadColumns(string filepath, string extn, bool isDownloadAction)
        {
            var columnNames = new List<string>();

            IWorkbook workbook;

            using (FileStream stream = new FileStream(filepath, FileMode.Open, FileAccess.Read))
            {
                if (extn == ".xls")
                {
                    workbook = new HSSFWorkbook(stream);
                }
                else
                {
                    workbook = new XSSFWorkbook(stream);
                }
            }

            ISheet sheet = workbook.GetSheetAt(0);

            IRow headerRow = sheet.GetRow(0);
            if (headerRow == null) throw new InvalidDataException("File is empty");
            foreach (ICell headerCell in headerRow)
            {
                if (!isDownloadAction)
                    columnNames.Add(headerCell.ToString().Trim().ToLower());
                else
                    columnNames.Add(headerCell.ToString().Trim());
            }

            return columnNames.AsEnumerable();
        }

        IEnumerable<Players> IExcelPlayerReader.ReadData(string filepath, string extn)
        {
            IWorkbook workbook;
            var players = new List<Players>();

            using (FileStream stream = new FileStream(filepath, FileMode.Open, FileAccess.Read))
            {
                if (extn == ".xls")
                {
                    workbook = new HSSFWorkbook(stream);
                }
                else
                {
                    workbook = new XSSFWorkbook(stream);
                }
            }

            ISheet sheet = workbook.GetSheetAt(0);

            var rows = new List<string>();

            IRow headerRow = sheet.GetRow(0);
            foreach (ICell headerCell in headerRow)
            {
                rows.Add(headerCell.ToString().Trim().ToLower());
            }

            int rowIndex = 0;

            foreach (IRow row in sheet)
            {
                if (rowIndex++ == 0) continue; // skip header row

                var playerData = row.Cells.Select(c => c.ToString().Trim()).ToList();

                if (playerData.Count == 0)
                {
                    continue;
                }
                else
                {

                    var player = new Players
                    {
                        PlayerName = row.GetCell(rows.FindIndex(x => x == "PlayerName".ToLower()))?.ToString().Trim(),
                        TeamName = row.GetCell(rows.FindIndex(x => x == "TeamName".ToLower()))?.ToString().Trim(),
                        Country = row.GetCell(rows.FindIndex(x => x == "Country".ToLower()))?.ToString().Trim(),
                        Sport = row.GetCell(rows.FindIndex(x => x == "Sport".ToLower()))?.ToString().Trim(),
                        Gender = row.GetCell(rows.FindIndex(x => x == "Gender".ToLower()))?.ToString().Trim()
                    };

                    string ageString = row.GetCell(rows.FindIndex(x => x == "Age".ToLower()))?.ToString().Trim();
                    if (int.TryParse(ageString, out int age))
                    {
                        player.Age = age;
                    }
                    else
                    {
                        // Handle the case where the age value is not a valid integer
                        // ... (error handling code here)
                    }

                    string teamIdString = row.GetCell(rows.FindIndex(x => x == "TeamId".ToLower()))?.ToString().Trim();
                    if (int.TryParse(teamIdString, out int teamId))
                    {
                        player.TeamId = teamId;
                    }
                    else
                    {
                        // Handle the case where the teamId value is not a valid integer
                        // ... (error handling code here)
                    }

                    players.Add(player);

                    foreach (var columnName in _context.Players.First().GetType().GetProperties().Select(p => p.Name))
                    {
                        var index = rows.FindIndex(x => x == columnName.ToLower());
                        if (index >= 0)
                        {
                            var cellValue = row.GetCell(index)?.ToString().Trim();
                            if (!string.IsNullOrEmpty(cellValue))
                            {
                                var propertyInfo = typeof(Players).GetProperty(columnName);
                                propertyInfo.SetValue(player, Convert.ChangeType(cellValue, propertyInfo.PropertyType));
                            }
                        }
                    }
                }
            }

            return players.AsEnumerable();
        }

        object IExcelPlayerReader.ReadData(string path, object extn)
        {
            throw new NotImplementedException();
        }
    }
}
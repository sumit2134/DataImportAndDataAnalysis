using System;
using OlympicsApplication.Models.Entity;

namespace OlympicsApplication.Functionality
{
    public interface IExcelReaderService
    {
        IEnumerable<string> ReadColumns(string filepath, string extn, bool isDownloadAction = false);

        IEnumerable<Team> ReadData(string filepath, string extn);
        object ReadData(string path, object extn);
    }
}
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using OlympicsApplication.Database;


namespace OlympicsApplication.Functionality
{
    public class OlympicsChartService : IOlympicsChartService
    {
        private readonly OlympicsDbContext _context;

        public OlympicsChartService(OlympicsDbContext context)
        {
            _context = context;
        }

        public async Task<List<object>> GetTopCountries()
        {
            var topCountries = await _context.Players
                .GroupBy(p => p.Country)
                .Select(g => new { Country = g.Key, PlayerCount = g.Count() })
                .OrderByDescending(g => g.PlayerCount)
                .Take(5)
                .ToListAsync();

            return topCountries.Cast<object>().ToList();
        }

        public List<object> GetPlayersByCountryAndSport()
        {
            var result = _context.Players
                .GroupBy(p => new { p.Country, p.Sport })
                .Select(g => new
                {
                    Country = g.Key.Country,
                    Sport = g.Key.Sport,
                    PlayerCount = g.Count()
                })
                .ToList();

            return result.Cast<object>().ToList();
        }

        public List<object> GetMedalData()
        {
            var medalData = _context.Medals
                .Select(m => new
                {
                    Country = m.Country,
                    Sport = m.Sport,
                    MedalType = m.Type,
                })
                .GroupBy(m => new { m.Country, m.Sport, m.MedalType })
                .Select(g => new
                {
                    g.Key.Country,
                    g.Key.Sport,
                    MedalType = g.Key.MedalType.ToString(),
                    Count = g.Count(),
                })
                .ToList();

            return medalData.Cast<object>().ToList();
        }

        public List<object> GetMedalsByCountry()
        {
            var medalData = _context.Medals
                .GroupBy(m => m.Country)
                .Select(g => new
                {
                    Country = g.Key,
                    TotalMedals = g.Count()
                })
                .OrderByDescending(g => g.TotalMedals)
                .ToList();

            return medalData.Cast<object>().ToList();
        }

        public List<object> GetPlayerCountBySport()
        {
            var playerCounts = _context.Players
                .GroupBy(p => p.Sport)
                .Select(g => new { Sport = g.Key, Count = g.Count() })
                .ToList();

            return playerCounts.Cast<object>().ToList();
        }

        public List<object> GetGenderCount()
        {
            var result = _context.Players
                .GroupBy(p => new { p.Sport, p.Gender })
                .Select(g => new {
                    Sport = g.Key.Sport,
                    Gender = g.Key.Gender,
                    Count = g.Count()
                })
                .ToList();

            return result.Cast<object>().ToList();
        }
    }
}


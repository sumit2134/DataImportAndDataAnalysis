using System;
using OlympicsApplication.Models.Entity;

namespace OlympicsApplication.Functionality
{
    public interface IExcelMedalReaderService
    {
        IEnumerable<string> ReadColumns(string filepath, string extn, bool isDownloadAction = false);
        IEnumerable<Medals> ReadData(string filepath, string extn);
        object ReadData(string path, object extn);
    }
}
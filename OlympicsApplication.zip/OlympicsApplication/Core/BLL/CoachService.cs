using System;
using OlympicsApplication.Models.Entity;
using OlympicsApplication.Database;


namespace OlympicsApplication.Functionality
{
    public class CoachService : ICoachService
    {
          private readonly OlympicsDbContext olympicsDbContext;
    


        public CoachService(OlympicsDbContext _olympicsDbContext)
        {
            olympicsDbContext = _olympicsDbContext;                             
        }

        int? ICoachService.AddCoach(Coach coach)
        {
            try
            {
             olympicsDbContext.Coaches.Add(coach);
             return olympicsDbContext.SaveChanges();
            }
            catch
            {
              return null;
            }
             olympicsDbContext.Coaches.Add(coach);
             return olympicsDbContext.SaveChanges();
        }

        List<Coach> ICoachService.GetCoachRecords()
        {
              return olympicsDbContext.Coaches.ToList();
        }

        Coach ICoachService.GetCoachSingleRecord(int id)
        {
            Coach coach=new Coach();
            coach = olympicsDbContext.Coaches.SingleOrDefault(t=>t.CoachId==id); 
            return coach;
        }

        void ICoachService.SaveCoach(List<Coach> coaches)
        {
          olympicsDbContext.Coaches.AddRange(coaches);
            olympicsDbContext.SaveChanges();
        }
    }
}
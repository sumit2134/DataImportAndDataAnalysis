using System;
using OlympicsApplication.Models.Entity;
using OlympicsApplication.OlympicsDTO;
using OlympicsApplication.Database;


namespace OlympicsApplication.Functionality
{
    public class MedalService : IMedalService
    {
        private readonly OlympicsDbContext olympicsDbContext;

        public MedalService(OlympicsDbContext _olympicsDbContext)
        {
            olympicsDbContext = _olympicsDbContext;
        }

        int? IMedalService.AddMedal(MedalViewModel medalViewModel)
        {
            {
                Medals objmedal = new Medals();
                int id = 0;
                id = objmedal.TeamId;
                objmedal.TeamId = medalViewModel.TeamId;
                objmedal.TeamName = medalViewModel.TeamName;
                objmedal.Country = medalViewModel.Country;
                objmedal.Sport = medalViewModel.Sport;
                objmedal.Rank = medalViewModel.Rank;
                objmedal.Type = medalViewModel.Type;

                olympicsDbContext.Medals.Add(objmedal);
                return olympicsDbContext.SaveChanges();
            }
        }

        int IMedalService.DeleteMedal(int id)
        {
            int result = 0;

            if (olympicsDbContext != null)
            {
                //Find the medal for specific team id
                var medal = olympicsDbContext.Medals.FirstOrDefault(x => x.TeamId == id);

                if (medal != null)
                {
                    //Delete that medal
                    olympicsDbContext.Medals.Remove(medal);

                    //Commit the transaction
                    result = olympicsDbContext.SaveChanges();
                }
                return result;
            }

            return result;
        }

        List<MedalViewModel> IMedalService.GetMedal()
        {


            if (olympicsDbContext != null)
            {
                return (from p in olympicsDbContext.Teams
                        from c in olympicsDbContext.Medals
                        from l in olympicsDbContext.Players

                        where p.TeamId == c.TeamId
                        where p.TeamId == l.TeamId
                        where c.TeamId == l.TeamId

                        select new MedalViewModel
                        {
                            TeamId = p.TeamId,
                            TeamName = p.TeamName,
                            Country = p.Country,
                            Sport = p.Sport,
                            Rank = c.Rank,
                            Type = c.Type,
                            PlayerName = l.PlayerName,
                            Gender = l.Gender
                        }).ToList();
            }

            return null;

        }

        async Task<MedalViewModel> IMedalService.GetMedal(int id)
        {
            if (olympicsDbContext != null)
            {
                return (from p in olympicsDbContext.Teams
                        from c in olympicsDbContext.Medals
                        from l in olympicsDbContext.Players


                        where p.TeamId == id
                        where c.TeamId == id
                        where l.TeamId == id

                        select new MedalViewModel
                        {
                            TeamId = p.TeamId,
                            TeamName = p.TeamName,
                            Country = p.Country,
                            Sport = p.Sport,
                            Rank = c.Rank,
                            Type = c.Type,
                            PlayerName = l.PlayerName,
                            Gender = l.Gender,

                        }).FirstOrDefault();
            }

            return null;
        }

        void IMedalService.SaveMedal(List<Medals> medals)
        {
            olympicsDbContext.Medals.AddRange(medals);
            olympicsDbContext.SaveChanges();
        }

        int IMedalService.UpdateMedal(MedalViewModel medalViewModel)
        {
              Medals objmedal = new Medals();
           int id=0;
           id=objmedal.TeamId;
           objmedal.TeamId=medalViewModel.TeamId; 
           objmedal.TeamName=medalViewModel.TeamName;
           objmedal.Country=medalViewModel.Country;
           objmedal.Rank=medalViewModel.Rank;
           objmedal.Type=medalViewModel.Type;
           objmedal.Sport=medalViewModel.Sport;
         

           olympicsDbContext.Medals.Add(objmedal);
           return olympicsDbContext.SaveChanges();
        }


    }
}
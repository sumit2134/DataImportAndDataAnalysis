using System;
using Microsoft.AspNetCore.Mvc;
using OlympicsApplication.Functionality;
using FluentValidation;
using OlympicsApplication.OlympicsDTO;
using OlympicsApplication.Core.Models.Entity;

namespace OlympicsApplication.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TeamController : ControllerBase
    {
        private readonly ITeamService _teamService;
        private readonly IValidator<TeamViewModel> _validator;
        private IWebHostEnvironment hostEnvironment;

        private IHttpContextAccessor httpContextAccessor;
        public TeamController(IValidator<TeamViewModel> validator, ITeamService teamService, IWebHostEnvironment _hostEnvironment, IHttpContextAccessor _httpContextAccessor)
        {
            _validator = validator;
            _teamService = teamService;
            hostEnvironment = _hostEnvironment;
            httpContextAccessor = _httpContextAccessor;
        }

        [HttpGet]
        public IActionResult FetchTeams(int pageNumber = 1, int pageSize = 10)
        {
            var totalCount = _teamService.GetTeams().Count();
            var teams = _teamService.GetTeams()
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToList();
            var teamViewModels = teams.Select(t => new TeamViewModel
            {
                TeamName = t.TeamName,
                Country = t.Country,
                Sport = t.Sport,


            }).ToList();


            var response = new PaginatedResponse<TeamViewModel>
            {
                TotalCount = totalCount,
                PageNumber = pageNumber,
                PageSize = pageSize,
                Data = teamViewModels
            };

            return Ok(_teamService.GetTeams());
        }


        [HttpPost]
        public IActionResult CreateTeams(TeamViewModel teamViewModel)
        {
            var validationResult = _validator.Validate(teamViewModel);
            if (validationResult.IsValid)
            {
                return Ok(_teamService.AddTeam(teamViewModel));
            }
            return BadRequest();
        }


        [Produces("application/json")]
        [HttpPost("upload")]
        public IActionResult Upload(IFormFile file)
        {
            try
            {
                var path = Path.Combine(hostEnvironment.WebRootPath, "uploads", file.FileName);
                using (var fileStream = new FileStream(path, FileMode.Create))
                {
                    file.CopyTo(fileStream);
                }
                var baseURL = httpContextAccessor.HttpContext.Request.Scheme + "://" +
                httpContextAccessor.HttpContext.Request.Host + httpContextAccessor.HttpContext.Request.PathBase;
                return Ok(new
                {
                    fileName = Path.Combine(baseURL, "/uploads", file.FileName)
                });
            }

            catch
            {
                return BadRequest();
            }
        }
    }
}
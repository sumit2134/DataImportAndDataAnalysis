using System;
using Microsoft.AspNetCore.Mvc;
using OlympicsApplication.Functionality;
using OlympicsApplication.OlympicsDTO;


namespace OlympicsApplication.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MedalController : ControllerBase
    {
        IMedalService iMedalService;
         private IWebHostEnvironment hostEnvironment;

        private IHttpContextAccessor httpContextAccessor;
        public MedalController(IMedalService _iMedalService,IWebHostEnvironment _hostEnvironment, IHttpContextAccessor _httpContextAccessor) 
        {

            iMedalService = _iMedalService;
             hostEnvironment = _hostEnvironment;
            httpContextAccessor = _httpContextAccessor;
        }

        [HttpPost("CreateMedal")]
        public IActionResult CreateMedal([FromBody] MedalViewModel viewModel)
        {
            return Ok(iMedalService.AddMedal(viewModel));
        }

        [HttpGet]
        [Route("GetMedal")]
        public async Task<IActionResult> GetMedal()
        {
            try
            {
                var medal = iMedalService.GetMedal();
                if (medal == null)
                {
                    return NotFound();
                }

                return Ok(medal);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpGet]
        [Route("GetMedalById")]
        public async Task<IActionResult> GetMedal(int id)
        {
            if (id == null)
            {
                return BadRequest();
            }

            try
            {
                var medal = await iMedalService.GetMedal(id);

                if (medal == null)
                {
                    return NotFound();
                }

                return Ok(medal);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Deleteplayer(int id)
        {
            return Ok(iMedalService.DeleteMedal(id));
        }

           [HttpPut("UpdateMedal")]
        public IActionResult UpdateMedal([FromBody] MedalViewModel viewModel)
        {
            return Ok(iMedalService.UpdateMedal(viewModel));
        }

           [Produces("application/json")]
        [HttpPost("upload")]
        public IActionResult Upload(IFormFile file)
        {
            try
            {
                var path = Path.Combine(hostEnvironment.WebRootPath, "uploads", file.FileName);
                using (var fileStream = new FileStream(path, FileMode.Create))
                {
                    file.CopyTo(fileStream);
                }
                var baseURL = httpContextAccessor.HttpContext.Request.Scheme + "://" +
                httpContextAccessor.HttpContext.Request.Host + httpContextAccessor.HttpContext.Request.PathBase;
                return Ok(new
                {
                    fileName = Path.Combine(baseURL, "/uploads", file.FileName)
                });
            }

            catch
            {
                return BadRequest();
            }


        }

    }
}
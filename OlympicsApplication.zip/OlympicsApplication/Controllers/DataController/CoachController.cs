using System;
using Microsoft.AspNetCore.Mvc;
using OlympicsApplication.Functionality;
using OlympicsApplication.OlympicsDTO;
using AutoMapper;
using OlympicsApplication.Models.Entity;

namespace OlympicsApplication.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CoachController : ControllerBase
    {
        IMapper imapper;
        ICoachService iCoachService;
        private object mapper;

        public CoachController(ICoachService _iCoachService, IMapper _imapper)
        {
            imapper = _imapper;
           iCoachService = _iCoachService;        
        }

        [HttpPost()]
        public IActionResult PostAddCoach([FromBody] CoachViewModel coachViewModel)
        { //applying by automapper
            var obj = imapper.Map<Coach>(coachViewModel);
            return Ok(iCoachService.AddCoach(obj));
        }

        [HttpGet()]
        public IActionResult GetCoachDetails()
        {
            return Ok(iCoachService.GetCoachRecords());
        }

        [HttpGet("{id}")]
        public IActionResult GetFetchSpecificEmployee(int id)
        {
            return Ok(iCoachService.GetCoachSingleRecord(id));
        }

     
    }
}
using System;
using Microsoft.AspNetCore.Mvc;
using OlympicsApplication.Functionality;

namespace OlympicsApplication.Controllers.DataController
{
    [ApiController]
    [Route("api/[controller]")]
    public class TopCountriesController : ControllerBase
    {

        IOlympicsChartService iolympicschartservice;
        public TopCountriesController(IOlympicsChartService _iolympicschartservice)
        {

            iolympicschartservice = _iolympicschartservice;
        }
        [HttpGet]
        public async Task<IActionResult> GetTopCountries()
        {
            var topCountries = await iolympicschartservice.GetTopCountries();

            return Ok(topCountries);
        }

        [HttpGet("players-by-country-and-sport")]
        public IActionResult GetPlayersByCountryAndSport()
        {
            var result = iolympicschartservice.GetPlayersByCountryAndSport();

            return Ok(result);
        }


        [HttpGet("medals-count")]
        public IActionResult GetMedalData()
        {
            var result = iolympicschartservice.GetMedalData();

            return Ok(result);
        }

        [HttpGet("medals-by-country")]
        public IActionResult GetMedalsByCountry()
        {
            var result = iolympicschartservice.GetMedalsByCountry();

            return Ok(result);
        }

        [HttpGet("gender-count")]
        public IActionResult GetPlayerCountByGender()
        {
            var result = iolympicschartservice.GetGenderCount();

            return Ok(result);
        }

        [HttpGet]
        [Route("api/players/count-by-sport")]
        public IActionResult GetPlayerCountBySport()
        {
            var playerCounts = iolympicschartservice.GetPlayerCountBySport();

            if (playerCounts == null)
            {
                return NotFound();
            }

            return Ok(playerCounts);

        }
    }

}





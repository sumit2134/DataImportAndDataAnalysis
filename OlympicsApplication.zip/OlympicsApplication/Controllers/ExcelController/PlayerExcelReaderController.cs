using System;
using Microsoft.AspNetCore.Mvc;
using OlympicsApplication.Functionality;
using OlympicsApplication.Models.Entity;
using OlympicsApplication.Database;

namespace OlympicsApplication.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PlayerExcelReaderController : ControllerBase
    {
         private readonly IExcelPlayerReader _excelReaderService;

        private readonly IPlayerService _playerService;
        private readonly OlympicsDbContext _dbContext;

        public PlayerExcelReaderController(IExcelPlayerReader excelReaderService,OlympicsDbContext dbContext, IPlayerService playerService)
        {
            _excelReaderService = excelReaderService;
            _dbContext = dbContext;

            _playerService = playerService;
        }

          [HttpPost("upload")]
        public IActionResult Upload(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest("File is empty");
            }

            var extn = Path.GetExtension(file.FileName);

            if (extn != ".xls" && extn != ".xlsx")
            {
                return BadRequest("Invalid file type");
            }

            var filepath = Path.GetTempFileName();

            using (var stream = new FileStream(filepath, FileMode.Create))
            {
                file.CopyTo(stream);
            }

            var columns = _excelReaderService.ReadColumns(filepath, extn, true);
            var data = _excelReaderService.ReadData(filepath, extn);
            var PlayerList = new List<Players>();
            try
            {
                foreach (var row in data)
                {
                    var player = new Players
                    {
                        TeamId = row.TeamId,
                        PlayerName = row.PlayerName,
                        TeamName = row.TeamName,
                        Country = row.Country,
                        Sport = row.Sport,
                        Age = row.Age,
                        Gender = row.Gender
                    };
                    PlayerList.Add(player);
                }

                    _playerService.SavePlayers(PlayerList);
            }
            catch (Exception ex)
            {
                // Handle any exceptions that occur during database operations
                return StatusCode(500, $"An error occurred while saving data to the database: {ex.Message}");
            }

            return Ok(new { Columns = columns, Data = data });
        }
    }
}
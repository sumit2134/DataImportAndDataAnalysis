using System;
using Microsoft.EntityFrameworkCore;
using OlympicsApplication.Models.EntityMapper;
using OlympicsApplication.Models.Entity;


namespace OlympicsApplication.Database
{
    public class OlympicsDbContext : DbContext
    {
        public OlympicsDbContext(DbContextOptions dbContextOptions) : base(dbContextOptions)
        {

        }
        
        public DbSet<Team> Teams {get ; set;}
        public DbSet<Players> Players {get; set;}

        public DbSet<Coach> Coaches {get; set;}
        public DbSet<Medals> Medals {get; set;}

        protected override void OnModelCreating(ModelBuilder modelbuilder)
        {
            new TeamMapper(modelbuilder.Entity<Team>());
            new PlayerMapper(modelbuilder.Entity<Players>());
            new MedalMapper(modelbuilder.Entity<Medals>());
            new CoachMapper(modelbuilder.Entity<Coach>());

            modelbuilder.Entity<Team>().HasData(new Team
            {
                 TeamId = 100,
                 TeamName = "IndianTigress",
                 Country = "India",
                 Sport = "Badminton"
            }
            );

            modelbuilder.Entity<Players>().HasData(new Players
            {
                PlayerId = 101,
                PlayerName = "Vaishnavi",
                Age = 21,
                Gender = "female",
                TeamId = 100,
                TeamName = "IndianTigress",
                Country = "India",
                Sport = "Badminton"
            }
            );
               
            modelbuilder.Entity<Coach>().HasData(new Coach
            {
                CoachId = 001,
                CoachName = "Vijender Singh",
                CoachAge = 40,
                TeamId = 100,
                TeamName = "IndianTigress",
                Country = "India",
                 Sport = "Badminton"
            });

            modelbuilder.Entity<Medals>().HasData(new Medals
            {
                Rank = 1,
                Type = "Gold",
                TeamId = 100,
                TeamName = "IndianTigress",
                Country = "India",
                Sport = "Badminton"
            });
    }
    }
}